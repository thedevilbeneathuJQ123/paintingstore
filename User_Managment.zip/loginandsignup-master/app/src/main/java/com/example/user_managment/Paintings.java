package com.example.user_managment;

import java.util.ArrayList;

public class Paintings {

    private ArrayList<Integer> P;
    public ArrayList<Integer> getP() {
        return P;
    }

    public void setP(ArrayList<Integer> p) {
        P = p;
    }

    public Paintings(ArrayList<Integer> p) {
        P = p;
    }

}
